def lambda_handler(*args, **kwargs):
    pass
